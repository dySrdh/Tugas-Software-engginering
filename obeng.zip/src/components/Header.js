import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./Header.module.css";

const Header = () => {
  const navigate = useNavigate();

  const onLogoObeng2ImageClick = useCallback(() => {
    navigate("/");
  }, [navigate]);

  const onSearchBarContainerClick = useCallback(() => {
    navigate("/searchlihatsemua");
  }, [navigate]);

  return (
    <div className={styles.header}>
      <div className={styles.headerChild} />
      <div className={styles.logoobeng2Parent}>
        <img
          className={styles.logoobeng2Icon}
          loading="lazy"
          alt=""
          src="/logoobeng-2@2x.png"
          onClick={onLogoObeng2ImageClick}
        />
        <div className={styles.searchbarWrapper}>
          <div className={styles.searchbar} onClick={onSearchBarContainerClick}>
            <img
              className={styles.searchbarChild}
              alt=""
              src="/rectangle-2.svg"
            />
            <img
              className={styles.icon}
              loading="lazy"
              alt=""
              src="/5186446-1@2x.png"
            />
          </div>
        </div>
      </div>
      <div className={styles.loginheaderbuttonWrapper}>
        <button className={styles.loginheaderbutton}>
          <img
            className={styles.loginheaderbuttonChild}
            alt=""
            src="/rectangle-3.svg"
          />
          <b className={styles.login}>Login</b>
        </button>
      </div>
    </div>
  );
};

export default Header;
