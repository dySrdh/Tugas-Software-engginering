import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import FrameComponent3 from "./FrameComponent3";
import styles from "./FrameComponent4.module.css";

const FrameComponent4 = () => {
  const navigate = useNavigate();

  const onSudahMempunyaiAkunClick = useCallback(() => {
    navigate("/login");
  }, [navigate]);

  return (
    <div className={styles.vectorParent}>
      <img className={styles.frameChild} alt="" src="/rectangle-121.svg" />
      <div className={styles.dropdownSignUp}>
        <div className={styles.username}>
          <b className={styles.signUp}>Sign Up</b>
        </div>
        <div className={styles.password}>
          <div className={styles.username1}>Username:</div>
          <img
            className={styles.passwordChild}
            loading="lazy"
            alt=""
            src="/rectangle-2.svg"
          />
          <div className={styles.emial}>Emial:</div>
          <img className={styles.passwordItem} alt="" src="/rectangle-2.svg" />
          <div className={styles.password1}>Password:</div>
          <img className={styles.passwordInner} alt="" src="/rectangle-2.svg" />
          <div className={styles.confirmPassword}>Confirm password:</div>
          <img className={styles.rectangleIcon} alt="" src="/rectangle-2.svg" />
          <div className={styles.dropsignup}>
            <img
              className={styles.dropsignupChild}
              alt=""
              src="/rectangle-2.svg"
            />
            <div className={styles.daftarSebagai}>Daftar sebagai:</div>
            <div className={styles.pilihanWrapper}>
              <div className={styles.pilihan}>
                <div className={styles.pilihanContainer}>
                  <div className={styles.pilihan1}>-Pilihan-</div>
                </div>
                <img
                  className={styles.contactUsIcon}
                  alt=""
                  src="/contact-us.svg"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
      <FrameComponent3
        masuk="Daftar"
        belumMempunyaiAkun="Sudah mempunyai akun? "
        signUp="Login!"
        propPadding="0px var(--padding-34xl)"
        onBelumMempunyaiAkunClick={onSudahMempunyaiAkunClick}
      />
    </div>
  );
};

export default FrameComponent4;
